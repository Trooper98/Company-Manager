assign3_Xiong_Manzi

Xiong was responsible for:
abstract Employee class
remove employee
total employees
total gross expense
print Employee 
update employee
demoting employee

Manzi was responsible for:
regular class
manager class
director class
intern class
register employee
promoting employee
total net expense
update director benefits

//notes on task 6
it was was very risky when try to down cast because employe do not share identical attributes in the constructors. It forces the programmer to prepare for all possible outcomes. 

It is ofter heard that down casting is safer than up casting, but that doesn’t change the fact that it is still very risky.