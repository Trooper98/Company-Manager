assign3_Xiong_Manzi

Xiong was responsible for:
abstract Employee class
remove employee
total employees
total gross expense
print Employee 
update employee
demoting employee

Manzi was responsible for:
regular, manager, director and intern class
register employee
promoting employee
total net expense
update director benefits
